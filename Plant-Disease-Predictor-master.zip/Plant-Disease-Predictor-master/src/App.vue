<template>
  <div id="q-app">
    <router-view class="fontChange" />
  </div>
</template>
<script>
export default {
  name: "App"
};
</script>
