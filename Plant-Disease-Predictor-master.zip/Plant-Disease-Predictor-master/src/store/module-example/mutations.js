export function someMutation (/* state */) {
}
