from django.apps import AppConfig


class PlantClassifyConfig(AppConfig):
    name = 'plant_classify'
